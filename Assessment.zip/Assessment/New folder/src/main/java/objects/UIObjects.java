package objects;

public class UIObjects {

	public String droppable = "//a[text()=\"Droppable\"]";
	                          //a[text()="Droppable"]
	public String draggable = "//div[@id='draggable']/p";
	public String dropElement = "//div[@id='droppable']/p";

	public String selectable = "//a[text()=\"Selectable\"]";
	public String items = "*//ol[@id=\"selectable\"]/li";

	public String controlgrps = "//a[text()=\"Controlgroup\"]";
	public String carType = "car-type-button";
	public String SUV = "//div[text()=\"SUV\"]";
	public String trnsmsnSTD = "//label[@for=\"transmission-standard\"]";
	public String insurance = "//label[@for=\"insurance\"]";
	public String trnsmsnSTDV = "//label[@for=\"transmission-standard-v\"]";
	public String insuranceV = "//label[@for=\"insurance-v\"]";
}
