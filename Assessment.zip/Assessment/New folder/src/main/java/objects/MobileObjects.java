package objects;

import org.openqa.selenium.By;

public class MobileObjects {

	public By permission = By.id("com.android.permissioncontroller:id/continue_button");
	public By backButton = By.id("io.selendroid.testapp:id/goBack");
	public By enButton = By.id("io.selendroid.testapp:id/buttonTest");
	public By okbuton = By.id("android:id/button1");
	public By noButton = By.id("android:id/button2");
	public By toolBarTitleBy = By.id("android:id/title");
	public By chromeButton = By.id("io.selendroid.testapp:id/buttonStartWebview");
	public By chromeTitle = By.xpath("//android.widget.TextView[@index='0']");
	public By progressButton = By.id("io.selendroid.testapp:id/waitingButtonTest");
	public By registerUserTitle = By.xpath("//android.widget.TextView[@index='0']");
	public By toastButton = By.id("io.selendroid.testapp:id/showToastButton");
	public By toastMsg = By.xpath("//android.widget.Toast[1]");
	public By exceptionButon = By.id("io.selendroid.testapp:id/exceptionTestButton");
}
