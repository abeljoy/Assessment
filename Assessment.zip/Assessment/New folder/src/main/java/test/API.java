package test;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import utils.Util;

public class API extends Util {
	static RequestSpecification httpRequest;

	@BeforeTest
	public void setup() {
		// Specify the base URL to the RESTful web service
		RestAssured.baseURI = "https://reqres.in/api";
		createReport("API Reports");
		// Get the RequestSpecification of the request to be sent to the server.
		httpRequest = RestAssured.given();

	}

	@Test
	public void getUsers() {
		logger = extent.createTest("Verify whether Candidate exists");
		Response res = httpRequest.queryParam("page", "2").get("/users");
		Assert.assertEquals(res.getStatusCode(), 200);
		JSONObject jsonObject = new JSONObject(res.getBody().asString());
		JSONArray jsonArray = jsonObject.getJSONArray("data");
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject explrObject = jsonArray.getJSONObject(i);
			if (explrObject.getInt("id") == 10) {
				if (explrObject.getString("first_name").equals("Byron")) {
					logger.log(Status.PASS, "Name verified successfully.!");
					break;
				} else
					logger.log(Status.FAIL, "Name verification failed.!");
			}
		}
	}

	@Test
	public void AddUser() {
		logger = extent.createTest("Add new user & verify ID");

		JSONObject requestParams = new JSONObject();
		requestParams.put("name", "test");
		requestParams.put("job", "test");
		httpRequest.body(requestParams.toString());
		logger.log(Status.INFO, "added body content to request");
		Response response = httpRequest.post("/users");
		logger.log(Status.INFO, "POST request initiated to the /users endpoint");
		JSONObject js = new JSONObject(response.getBody().asString());
		Assert.assertEquals(response.getStatusCode(), 201);
		if (js.has("id") && !js.getString("id").equals("")) {
			logger.log(Status.INFO, "Status code is " + response.getStatusCode());
			logger.log(Status.INFO, "New id created:" + js.getString("id"));
		}
	}

	@AfterMethod
	public void getResult(ITestResult result) throws Exception {
		if (result.getStatus() == ITestResult.FAILURE) {
			logger.log(Status.FAIL,
					MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
			logger.log(Status.FAIL,
					MarkupHelper.createLabel(result.getThrowable() + " - Test Case Failed", ExtentColor.RED));

		} else if (result.getStatus() == ITestResult.SKIP) {
			logger.log(Status.SKIP,
					MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.ORANGE));
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			logger.log(Status.PASS,
					MarkupHelper.createLabel(result.getName() + " Test Case PASSED", ExtentColor.GREEN));
		}
	}

	@AfterTest
	public void endReport() {
		extent.flush();
	}
}
