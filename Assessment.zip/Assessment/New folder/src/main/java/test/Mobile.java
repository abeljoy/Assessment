package test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import base.BaseClass;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import objects.MobileObjects;
import utils.Util;

public class Mobile extends Util {
	AndroidDriver<MobileElement> driver;

	public WebDriverWait wait;
	BaseClass browser;
	MobileObjects obj;

	@BeforeTest
	public void startTest() {
		createReport("Appium Reports");
		browser = new BaseClass();
		obj = new MobileObjects();
	}

	@BeforeMethod
	public void setup() throws MalformedURLException {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("deviceName", "OPPO F19s");
		capabilities.setCapability("platformVersion", "11");
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("appPackage", "io.selendroid.testapp");
		capabilities.setCapability("appActivity", "io.selendroid.testapp.HomeScreenActivity");
		driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);

		System.out.println("Server connected");

		System.out.println("Listening to Appium server...");
		// browser.initialize("Mobile");
		 wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.permission)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.okbuton)).click();
	}

	@Test
	public void test1() {
		logger = extent.createTest("Verify whether Title is valid");
		Assert.assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(obj.toolBarTitleBy)).getText(),
				"selendroid-test-app");
	}

	@Test
	public void test2() {
		logger = extent.createTest("Verify whether Title exists after clicking EN button");
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.enButton)).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.noButton)).click();
		Assert.assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(obj.toolBarTitleBy)).getText(),
				"selendroid-test-app");
	}

	@Test
	public void test3() {
		logger = extent.createTest("Verify whether Title is valid after clicking chrome button");
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.chromeButton)).click();

		Assert.assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(obj.chromeTitle)).getText(),
				"Web View Interaction");
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.backButton)).click();

	}

	@Test
	public void test5() {
		logger = extent.createTest("Verify whether Title is valid after clicking progress button");
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.progressButton)).click();
		Assert.assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(obj.registerUserTitle)).getText(),
				"Welcome to register a new User");
		List<MobileElement> elementsTwo = (List<MobileElement>) driver.findElements((obj.chromeTitle));

		Assert.assertEquals(elementsTwo.get(2).getText(), "Web View Interaction");
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.backButton)).click();

	}
	@Test
	public void test6() {
		logger = extent.createTest("Verify the toast text");
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.toastButton)).click();
		Assert.assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(obj.toastMsg)).getText(),
				"Hello selendroid toast!");

	}
	@Test
	public void test8() {
		logger = extent.createTest("Verify whether Title is valid after clicking exception button");
		wait.until(ExpectedConditions.visibilityOfElementLocated(obj.exceptionButon)).click();
		Assert.assertEquals(wait.until(ExpectedConditions.visibilityOfElementLocated(obj.toolBarTitleBy)).getText(),
				"selendroid-test-app");

	}

	@AfterMethod
	public void getResult(ITestResult result) throws Exception {

		if (result.getStatus() == ITestResult.FAILURE) {
			logger.log(Status.FAIL,
					MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
			logger.log(Status.FAIL,
					MarkupHelper.createLabel(result.getThrowable() + " - Test Case Failed", ExtentColor.RED));

		} else if (result.getStatus() == ITestResult.SKIP) {
			logger.log(Status.SKIP,
					MarkupHelper.createLabel(result.getName() + " - Test Case Skipped", ExtentColor.ORANGE));
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			logger.log(Status.PASS,
					MarkupHelper.createLabel(result.getName() + " Test Case PASSED", ExtentColor.GREEN));
		}
		driver.quit();
	}

	@AfterTest
	public void endReport() {
		extent.flush();
	}

}
