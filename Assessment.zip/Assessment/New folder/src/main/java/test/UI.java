package test;

import java.net.MalformedURLException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import base.BaseClass;
import objects.UIObjects;
import utils.Util;

public class UI extends Util {
	WebDriver driver;
	BaseClass browser;
	UIObjects obj;

	@BeforeTest
	public void startTest() {
		createReport("UI Reports");
		browser = new BaseClass();
		obj = new UIObjects();
	}

	@BeforeMethod
	public void beforeMethod() throws MalformedURLException {
		browser.initialize("UI");
		browser.fetch("https://jqueryui.com/");
	}

	@Test
	public void dragDrop() throws InterruptedException {
		logger = extent.createTest("Drag n drop Functionality");
		browser.click("xpath", obj.droppable);
		browser.switchFrame(0);
		WebElement from = browser.getElement("xpath", obj.draggable);
		WebElement to = browser.getElement("xpath", obj.dropElement);
		Thread.sleep(4000);

		Actions action = new Actions(browser.getDriver());
		action.dragAndDrop(from, to).build().perform();
		Thread.sleep(4000);	
		logger.log(Status.PASS, "Drag and drop performed");
	}

	@Test
	public void select() {
		logger = extent.createTest("Select multiple data from list");

		browser.click("xpath", obj.selectable);
		browser.switchFrame(0);
		List<WebElement> data = browser.getElements("xpath", obj.items);
		data.get(0).click();
		logger.log(Status.INFO, "Clicked on item 1");
		data.get(2).click();
		logger.log(Status.INFO, "Clicked on item 3");
		data.get(6).click();
		logger.log(Status.INFO, "Clicked on item 7");
		logger.log(Status.PASS, "Selected multiple data from the list");
	}

	@Test
	public void Controlgrp() {
		logger = extent.createTest("Multiform data fill in control group");

		browser.click("xpath", obj.controlgrps);
		browser.switchFrame(0);
		browser.click("id", obj.carType);
		logger.log(Status.INFO, "Clicked on Car type");
		browser.click("xpath", obj.SUV);
		logger.log(Status.INFO, "Selected value as SUV");
		browser.click("xpath", obj.trnsmsnSTD);
		logger.log(Status.INFO, "Clicked on transmission");
		browser.click("xpath", obj.insurance);
		logger.log(Status.INFO, "Clicked on insurance");
		browser.getElement("id", "horizontal-spinner").sendKeys("2");
		logger.log(Status.INFO, "Added value as 2");
		browser.click("xpath", obj.trnsmsnSTDV);
		logger.log(Status.INFO, "Added transmission standard");
		browser.click("xpath", obj.insuranceV);
		logger.log(Status.INFO, "Clicked on insurance");
		browser.getElement("id", "vertical-spinner").sendKeys("1");
		logger.log(Status.INFO, "Added value as 1");
		browser.click("id", "book");
		logger.log(Status.INFO, "Clicked on BOOK button");

		logger.log(Status.PASS, "Multiform actions done in control group");
	}

	@AfterMethod
	public void afterMethod() {
		browser.close();
	}

	@AfterTest
	public void endReport() {
		extent.flush();
	}
}
