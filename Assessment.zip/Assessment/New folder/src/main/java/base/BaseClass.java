package base;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class BaseClass {
	WebDriver driver;

	public void initialize(String type) throws MalformedURLException {
		switch (type) {
		case "UI": {
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			break;
		}
		case "Mobile": {
//			DesiredCapabilities capabilities = new DesiredCapabilities();
//			capabilities.setCapability("deviceName", "emulator-5554");
//			capabilities.setCapability("platformVersion", "11");
//			capabilities.setCapability("platformName", "Android");
//			capabilities.setCapability("skipUnlock", "true");
//			capabilities.setCapability("noReset", false);
//			capabilities.setCapability("autoGrantPermissions", true);
//			capabilities.setCapability("appPackage", "io.selendroid.testapp");
//			capabilities.setCapability("appActivity", "io.selendroid.testapp.HomeScreenActivity");
//			driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
//			System.out.println("Server connected");
//
//			System.out.println("Listening to Appium server...");
			break;
		}

		}

	}

	public void fetch(String url) {
		driver.get(url);
	}

	public WebElement getElement(String locator, String value) {
		switch (locator) {
		case "id":
			return driver.findElement(By.id(value));
		case "name":
			return driver.findElement(By.name(value));

		case "xpath":
			return driver.findElement(By.xpath(value));

		}
		return null;

	}

	public List<WebElement> getElements(String locator, String value) {
		switch (locator) {
		case "id":
			return driver.findElements(By.id(value));
		case "name":
			return driver.findElements(By.name(value));

		case "xpath":
			return driver.findElements(By.xpath(value));

		}
		return null;

	}

	public WebDriver getDriver() {
		return driver;
	}

	public void switchFrame(int index) {
		driver.switchTo().frame(index);
	}

	public void click(String locator, String value) {
		getElement(locator, value).click();
	}

	public void close() {
		driver.close();
	}
}
